#ifndef __HEAD_H__
#define __HEAD_H__
using namespace std;
class Counter
{
	public:

		int cnt[1000];
		Counter(int id);
		
		~Counter();
        
        void show();
        //{
          //  for (int i=0;i<1000;i++) if (cnt[i]>0)
            //{
                //INFO("Counter", i,cnt[i]);

            //}
        //}

};


#endif